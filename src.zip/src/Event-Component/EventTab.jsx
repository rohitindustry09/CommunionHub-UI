import React from 'react'

const EventTab = () => {
  return (
    <div>EventTab</div>
  )
}

export default EventTab